exports.owHandler = function(params) {

    // test invocation and response timing

    // response creation
    return {
        body: {
            "test": "latency_test"
        }
    };
}