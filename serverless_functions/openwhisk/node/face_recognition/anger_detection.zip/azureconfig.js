module.exports = {
    endpoint: "https://computerfacialvisor.cognitiveservices.azure.com/",
    key: "5a30ebee3b5f40e89f3d46871f802872"
}