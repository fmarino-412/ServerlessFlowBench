# noinspection DuplicatedCode,PyUnusedLocal
def ow_handler(request):

	# test invocation and response timing

	# response creation and return
	return {
		'body': {
			'test': 'latency test'
		}
	}
