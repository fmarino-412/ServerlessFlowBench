# noinspection DuplicatedCode
def ow_handler(request):

	# test invocation and response timing

	# response creation and return
	return {
		# 'headers': {
		# 	'Content-Type': 'application/json'
		# },
		# 'statusCode': 200,
		'body': {
			'test': 'latency test'
		}
	}
