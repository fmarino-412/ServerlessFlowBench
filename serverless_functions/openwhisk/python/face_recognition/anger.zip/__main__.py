# noinspection DuplicatedCode
def ow_handler(request):

	# search for number to factorize in request

	# prepare and return response
	return {
		'body': {
			'result': 'Anger detected'
		}
	}
