endpoint = "https://computervisor.cognitiveservices.azure.com/"
key = "2b9078d962af4646aa7b99bf16df844b"