# noinspection DuplicatedCode
def ow_handler(request):

	# response creation and return
	return {
		'body': {
			'url': 'https://images.freeimages.com/images/large-previews/8c4/requiem-for-a-daily-dream-2-1428558.jpg'
		}
	}
